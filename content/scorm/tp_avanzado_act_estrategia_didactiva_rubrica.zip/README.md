# OVA - Rúbrica: Creando una estrategia de enseñanza y aprendizaje incorporando TIC

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/

**Version:** 1.1

**Release:** 20190107.1
