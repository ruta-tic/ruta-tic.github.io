# OVA - Diga cómo evalúa y le diré qué docente es

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/

**Version:** 1.1

**Release:** 20190107.1
