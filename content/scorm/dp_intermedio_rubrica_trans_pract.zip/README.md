# OVA - Rúbrica: Foro. Propuesta de transformación de una práctica evaluativa de un curso o contenido de su práctica docente

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/

**Version:** 1.1

**Release:** 20190107.1
