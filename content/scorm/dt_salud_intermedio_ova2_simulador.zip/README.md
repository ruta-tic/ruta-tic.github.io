# OVA - La telesalud - Simulador

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/

**Version:** 1.1

**Release:** 20190107.1
