# OVA - Rúbrica: Foro. Construcción colectiva sobre experiencias formativas en CDIO

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/

**Version:** 1.1

**Release:** 20190107.1
