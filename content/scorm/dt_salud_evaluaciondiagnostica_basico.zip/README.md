# OVA - Rúbrica: Evaluación diagnóstica nivel Iniciación Tecnologías en salud

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/

**Version:** 1.1

**Release:** 20190107.1
