# OVA - Guía para integrar tecnología en los procesos de enseñanza y aprendizaje: Modelo SAMR

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/

**Version:** 1.1

**Release:** 20190107.1
