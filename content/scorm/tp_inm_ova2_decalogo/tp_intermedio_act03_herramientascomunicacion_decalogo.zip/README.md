# OVA - Decálogo: 10 reglas de oro para la comunicación mediada por tecnologías digitales

Producido en **Tepuy** - Template for interactive content editing
https://github.com/davidherney/tepuy/
**Version:** 1.1
**Release:** 20190107.1
